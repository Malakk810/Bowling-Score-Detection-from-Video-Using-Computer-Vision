# cv_project_2classes > 2026-05-05 10:44am
https://universe.roboflow.com/malaks-workspace-c8zfr/cv_project_2classes

Provided by a Roboflow user
License: CC BY 4.0

